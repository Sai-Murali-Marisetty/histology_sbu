import os
import json
import argparse
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from tqdm import tqdm

from cellpose.models import CellposeModel
from skimage.measure import regionprops
from scipy.spatial import cKDTree

import matplotlib.pyplot as plt
from matplotlib import cm


def _ensure_uint16(arr):
    if arr.dtype != np.uint16:
        if arr.max() > np.iinfo(np.uint16).max:
            raise ValueError("Label IDs exceed uint16 range.")
        return arr.astype(np.uint16)
    return arr


def _props_from_labelmask(label_img):
            for p in regionprops(label_img):
                yield {
                    "label": int(p.label),
                    "cy": float(p.centroid[0]),
                    "cx": float(p.centroid[1]),
                    "area_px": float(p.area),
                    "perimeter_px": float(getattr(p, "perimeter", 0.0)),
                    "eccentricity": float(getattr(p, "eccentricity", 0.0)),
                    "solidity": float(getattr(p, "solidity", 0.0)),
                    "major_axis_length": float(getattr(p, "major_axis_length", 0.0)),
                    "minor_axis_length": float(getattr(p, "minor_axis_length", 0.0)),
                    "orientation": float(getattr(p, "orientation", 0.0)),  # ADD THIS LINE
                }


def stable_id(slide, x_um, y_um, ndigits=1):
    key = f"{slide}:{round(x_um, ndigits)}:{round(y_um, ndigits)}"
    return hashlib.md5(key.encode("utf-8")).hexdigest()[:16]


def dedup_by_radius(df, radius_um, prefer_col="area_px"):
    sort_idx = np.argsort(df[prefer_col].to_numpy(np.float64))[::-1]
    dfs = df.iloc[sort_idx].reset_index(drop=False).rename(columns={"index": "_orig_idx"})

    coords = dfs[["x_um", "y_um"]].to_numpy(np.float32)
    tree = cKDTree(coords)
    keep = np.ones(len(dfs), dtype=bool)

    for i in range(len(dfs)):
        if not keep[i]:
            continue
        nbrs = tree.query_ball_point(coords[i], r=radius_um)
        for j in nbrs:
            if j == i:
                continue
            keep[j] = False

    kept = dfs.loc[keep].copy()
    kept = kept.sort_values("_orig_idx").drop(columns=["_orig_idx"]).reset_index(drop=True)
    return kept


def process_batch(model, batch_imgs, batch_infos, diam_px, masks_dir, tiles_dir, viz_dir):
    masks_out, *_ = model.eval(
        batch_imgs,
        diameter=diam_px,
        channels=[0, 0],
        batch_size=len(batch_imgs)
    )

    if isinstance(masks_out, np.ndarray):
        masks_out = [masks_out] if masks_out.ndim == 2 else list(masks_out)

    rows = []
    for (x, y, tile_name), label_img in zip(batch_infos, masks_out):
        if label_img is None or label_img.max() == 0:
            continue

        # === Save 16-bit mask ===
        mask_path = os.path.join(masks_dir, f"mask_{x}_{y}.png")
        Image.fromarray(_ensure_uint16(label_img), mode="I;16").save(mask_path)

        # === Save overlay JPEG ===
        try:
            tile_path = os.path.join(tiles_dir, tile_name)
            tile_img = np.array(Image.open(tile_path).convert("RGB"))

            label_overlay = cm.nipy_spectral(label_img / (label_img.max() + 1e-5))[:, :, :3]
            label_overlay = (label_overlay * 255).astype(np.uint8)

            overlay = (0.6 * tile_img + 0.4 * label_overlay).astype(np.uint8)

            viz_path = os.path.join(viz_dir, f"preview_{x}_{y}.jpg")
            Image.fromarray(overlay).save(viz_path)
        except Exception as e:
            print(f"⚠️ Could not save overlay for {tile_name}: {e}")
            tile_img = None  # fallback: no color features

        # === Extract features ===
        if tile_img is None:
            continue

        for P in _props_from_labelmask(label_img):
            major = P["major_axis_length"]
            minor = P["minor_axis_length"]
            aspect = (major / minor) if minor > 0 else 0.0

            # Extract RGB mean intensities
            mask = (label_img == P["label"])
            if mask.sum() > 0:
                r_mean = float(tile_img[:, :, 0][mask].mean())
                g_mean = float(tile_img[:, :, 1][mask].mean())
                b_mean = float(tile_img[:, :, 2][mask].mean())
            else:
                r_mean = g_mean = b_mean = 0.0

            rows.append({
                "x": x + P["cx"],
                "y": y + P["cy"],
                "area_px": P["area_px"],
                "perimeter_px": P["perimeter_px"],
                "eccentricity": P["eccentricity"],
                "solidity": P["solidity"],
                "major_axis_length": major,
                "minor_axis_length": minor,
                "aspect_ratio": aspect,
                "orientation": P["orientation"],  # ADD THIS LINE
                "r": r_mean,
                "g": g_mean,
                "b": b_mean,
                "tile_x": x,
                "tile_y": y,
                "tile_id": f"{x}_{y}",
                "tile": tile_name,
                "label": P["label"],
            })
    return rows


def make_qc_panel(viz_dir, out_path, max_images=5):
    previews = sorted(Path(viz_dir).glob("preview_*.jpg"))
    if not previews:
        print("⚠️ No overlay previews found.")
        return
    images = [Image.open(p) for p in previews[:max_images]]
    widths, heights = zip(*(img.size for img in images))
    panel = Image.new("RGB", (sum(widths), max(heights)))
    x_offset = 0
    for img in images:
        panel.paste(img, (x_offset, 0))
        x_offset += img.width
    panel.save(out_path)
    print(f"🖼️ QC panel saved: {out_path}")


def segment_and_merge(tiles_dir, tiles_json, masks_dir, out_csv,
                      slide_id, mpp, diam_um, batch_size, gpu, dedup_radius_um):

    with open(tiles_json, "r") as f:
        meta = json.load(f)
    tiles = meta["tiles"]
    print(f"📦 Loaded {len(tiles)} tiles from {tiles_json}")

    Path(masks_dir).mkdir(parents=True, exist_ok=True)
    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    viz_dir = Path(masks_dir).parent / "viz"
    viz_dir.mkdir(parents=True, exist_ok=True)

    diam_px = float(diam_um) / float(mpp)
    print(f"📏 Cell diameter: {diam_um} µm → {diam_px:.1f} px at {mpp:.4f} µm/px")

    model = CellposeModel(gpu=gpu, pretrained_model="cyto2")
    print(f"🧠 Cellpose model loaded (GPU={gpu}, model=cyto2)")

    all_rows = []
    batch_imgs, batch_infos = [], []

    for t in tqdm(tiles, desc="🔍 Segmenting tiles"):
        x, y, w, h = t["x"], t["y"], t["w"], t["h"]
        tile_name = f"tile_{x}_{y}.png"
        tile_path = os.path.join(tiles_dir, tile_name)
        if not os.path.exists(tile_path):
            print(f"⚠️ Missing tile: {tile_name}")
            continue

        img = np.array(Image.open(tile_path).convert("RGB"))
        batch_imgs.append(img)
        batch_infos.append((x, y, tile_name))

        if len(batch_imgs) >= batch_size:
            rows = process_batch(model, batch_imgs, batch_infos, diam_px, masks_dir, tiles_dir, viz_dir)
            all_rows.extend(rows)
            batch_imgs, batch_infos = [], []

    if batch_imgs:
        rows = process_batch(model, batch_imgs, batch_infos, diam_px, masks_dir, tiles_dir, viz_dir)
        all_rows.extend(rows)

    df = pd.DataFrame(all_rows)
    print(f"🔬 Nuclei before dedup: {len(df):,}")

    df["x_um"] = df["x"] * mpp
    df["y_um"] = df["y"] * mpp

    df = dedup_by_radius(df, dedup_radius_um)
    print(f"✅ After deduplication: {len(df):,} nuclei (radius={dedup_radius_um} µm)")

    df["slide_id"] = slide_id
    df["nucleus_id"] = [
        stable_id(slide_id, x, y) for x, y in zip(df["x_um"], df["y_um"])
    ]

    key_cols = ["slide_id", "nucleus_id", "x", "y", "x_um", "y_um", "area_px"]
    df = df[key_cols + [c for c in df.columns if c not in key_cols]]

    df.to_csv(out_csv, index=False)
    print(f"📄 Saved features CSV: {out_csv}")

    # Generate QC panel
    make_qc_panel(viz_dir, Path(masks_dir).parent / f"qc_panel.jpg")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--tiles_dir", required=True)
    ap.add_argument("--tiles_json", required=True)
    ap.add_argument("--masks_dir", required=True)
    ap.add_argument("--out_csv", required=True)
    ap.add_argument("--slide_id", required=True)
    ap.add_argument("--mpp", type=float, required=True)
    ap.add_argument("--diam_um", type=float, default=10.0)
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--gpu", action="store_true")
    ap.add_argument("--dedup_radius_um", type=float, default=6.0)
    args = ap.parse_args()

    segment_and_merge(
        tiles_dir=args.tiles_dir,
        tiles_json=args.tiles_json,
        masks_dir=args.masks_dir,
        out_csv=args.out_csv,
        slide_id=args.slide_id,
        mpp=args.mpp,
        diam_um=args.diam_um,
        batch_size=args.batch_size,
        gpu=args.gpu,
        dedup_radius_um=args.dedup_radius_um
    )
