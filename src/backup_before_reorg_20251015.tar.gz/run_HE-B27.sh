#!/bin/bash
bash src/run_one_slide.sh data/raw/HE=B27.svs 2>&1 | tee logs/HE-B27.log
