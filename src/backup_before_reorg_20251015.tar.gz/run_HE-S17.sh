#!/bin/bash
bash src/run_one_slide.sh data/raw/HE-S17.svs 2>&1 | tee logs/HE-S17.log
