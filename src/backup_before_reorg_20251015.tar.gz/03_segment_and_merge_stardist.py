# src/03_segment_and_merge_stardist.py
import os, json, argparse, hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from tqdm import tqdm

from stardist.models import StarDist2D
from csbdeep.utils import normalize
from skimage.measure import regionprops
from scipy.spatial import cKDTree
import matplotlib.pyplot as plt

def _ensure_uint16(arr):
    if arr.dtype != np.uint16:
        if arr.max() > np.iinfo(np.uint16).max:
            raise ValueError("Label IDs exceed uint16 range.")
        return arr.astype(np.uint16)
    return arr

def _props_from_labelmask(label_img):
    for p in regionprops(label_img):
        yield {
            "label": int(p.label),
            "cy": float(p.centroid[0]),
            "cx": float(p.centroid[1]),
            "area_px": float(p.area),
            "perimeter_px": float(getattr(p, "perimeter", 0.0)),
            "eccentricity": float(getattr(p, "eccentricity", 0.0)),
            "solidity": float(getattr(p, "solidity", 0.0)),
            "major_axis_length": float(getattr(p, "major_axis_length", 0.0)),
            "minor_axis_length": float(getattr(p, "minor_axis_length", 0.0)),
        }

def stable_id(slide, x_um, y_um, ndigits=1):
    key = f"{slide}:{round(x_um, ndigits)}:{round(y_um, ndigits)}"
    return hashlib.md5(key.encode("utf-8")).hexdigest()[:16]

def dedup_by_radius(df, radius_um, prefer_col="area_px"):
    sort_idx = np.argsort(df[prefer_col].to_numpy(np.float64))[::-1]
    dfs = df.iloc[sort_idx].reset_index(drop=True)
    coords = dfs[["x_um", "y_um"]].to_numpy(np.float32)
    tree = cKDTree(coords)
    keep = np.ones(len(dfs), dtype=bool)
    for i in range(len(dfs)):
        if not keep[i]: continue
        for j in tree.query_ball_point(coords[i], r=radius_um):
            if j != i: keep[j] = False
    return dfs.loc[keep].reset_index(drop=True)

def process_batch(model, batch_imgs, batch_infos, diam_px, masks_dir, tiles_dir, viz_dir, prob_thresh, nms_thresh):
    import cv2
    rows = []
    for (x, y, tile_name), img in zip(batch_infos, batch_imgs):
        img_rgb = np.asarray(img)
        img_gray = np.dot(img_rgb[...,:3], [0.2989, 0.5870, 0.1140]).astype(np.float32)
        img_norm = normalize(img_gray, 1, 99.8)

        labels, _ = model.predict_instances(img_norm, prob_thresh=prob_thresh, nms_thresh=nms_thresh)
        if labels is None or labels.max() == 0: 
            continue
        label_img = _ensure_uint16(labels)

        # save mask
        Image.fromarray(label_img).save(os.path.join(masks_dir, f"mask_{x}_{y}.png"))

        # overlay preview
        preview = img_rgb.copy()
        contours, _ = cv2.findContours((label_img > 0).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(preview, contours, -1, (255, 0, 0), 2)
        Image.fromarray(preview).save(os.path.join(viz_dir, f"preview_{x}_{y}.jpg"))

        for P in _props_from_labelmask(label_img):
            lbl = P["label"]
            m = (label_img == lbl)
            r = float(img_rgb[...,0][m].mean()) if m.any() else 0.0
            g = float(img_rgb[...,1][m].mean()) if m.any() else 0.0
            b = float(img_rgb[...,2][m].mean()) if m.any() else 0.0
            major = P["major_axis_length"]; minor = P["minor_axis_length"]
            aspect = float(major/minor) if minor > 0 else 0.0
            rows.append({
                "tile": tile_name, "tile_x": x, "tile_y": y, "label": lbl,
                "cx": P["cx"], "cy": P["cy"], "x_px": P["cx"], "y_px": P["cy"],
                "area_px": P["area_px"], "perimeter_px": P["perimeter_px"],
                "eccentricity": P["eccentricity"], "solidity": P["solidity"],
                "major_axis_length": major, "minor_axis_length": minor, "aspect_ratio": aspect,
                "r": r, "g": g, "b": b, "tile_id": f"{x}_{y}",
            })
    return rows

def make_qc_panel(viz_dir, out_path, max_images=5):
    previews = sorted(Path(viz_dir).glob("preview_*.jpg"))
    if not previews:
        print("⚠️ No overlay previews found."); return
    images = [Image.open(p) for p in previews[:max_images]]
    widths, heights = zip(*(img.size for img in images))
    panel = Image.new("RGB", (sum(widths), max(heights)))
    x_offset = 0
    for img in images:
        panel.paste(img, (x_offset, 0)); x_offset += img.width
    panel.save(out_path); print(f"🖼️ QC panel saved: {out_path}")

def segment_and_merge(tiles_dir, tiles_json, masks_dir, out_csv,
                      slide_id, mpp, diam_um, batch_size, gpu, dedup_radius_um,
                      stardist_model, prob_thresh, nms_thresh):
    with open(tiles_json, "r") as f: meta = json.load(f)
    tiles = meta["tiles"]; print(f"📦 Loaded {len(tiles)} tiles from {tiles_json}")

    Path(masks_dir).mkdir(parents=True, exist_ok=True)
    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    viz_dir = Path(masks_dir).parent / "viz"; viz_dir.mkdir(parents=True, exist_ok=True)

    # choose model
    if stardist_model.lower() in {"2d_versatile_he", "versatile_he"}:
        model = StarDist2D.from_pretrained("2D_versatile_he")
    elif stardist_model.lower() in {"2d_versatile_fluo", "versatile_fluo"}:
        model = StarDist2D.from_pretrained("2D_versatile_fluo")
    else:
        model = StarDist2D(None, name=Path(stardist_model).name, basedir=str(Path(stardist_model).parent))

    diam_px = float(diam_um) / float(mpp)
    print(f"📏 Target nucleus diameter: {diam_um} µm → ~{diam_px:.1f} px at {mpp:.4f} µm/px (StarDist ignores diameter)")

    all_rows, batch_imgs, batch_infos = [], [], []
    for t in tqdm(tiles, desc="Segmenting (StarDist)"):
        x, y = t["x"], t["y"]
        tile_name = f"tile_{x}_{y}.png"
        tile_path = os.path.join(tiles_dir, tile_name)
        if not os.path.exists(tile_path):
            print(f"⚠️ Missing tile: {tile_name}"); continue
        img = Image.open(tile_path).convert("RGB")
        batch_imgs.append(img); batch_infos.append((x, y, tile_name))
        if len(batch_imgs) >= batch_size:
            all_rows += process_batch(model, batch_imgs, batch_infos, diam_px, masks_dir, tiles_dir, viz_dir, prob_thresh, nms_thresh)
            batch_imgs, batch_infos = [], []
    if batch_imgs:
        all_rows += process_batch(model, batch_imgs, batch_infos, diam_px, masks_dir, tiles_dir, viz_dir, prob_thresh, nms_thresh)

    if not all_rows:
        print("⚠️ No nuclei detected."); pd.DataFrame(columns=["slide_id","nucleus_id"]).to_csv(out_csv, index=False); return

    df = pd.DataFrame(all_rows)

    # map to absolute coords
    tile_size = meta.get("tile_size", 1024)
    abs_x_px, abs_y_px = [], []
    for _, row in df.iterrows():
        tx, ty = map(int, row["tile_id"].split("_"))
        # try explicit origins if present, else tile grid * tile_size
        ox = next((tt.get("x0_px", tt.get("x0", tx*tile_size)) for tt in tiles if tt["x"]==tx and tt["y"]==ty), tx*tile_size)
        oy = next((tt.get("y0_px", tt.get("y0", ty*tile_size)) for tt in tiles if tt["x"]==tx and tt["y"]==ty), ty*tile_size)
        abs_x_px.append(ox + row["x_px"]); abs_y_px.append(oy + row["y_px"])
    df["x"] = np.array(abs_x_px, dtype=np.float32)
    df["y"] = np.array(abs_y_px, dtype=np.float32)
    df["x_um"] = df["x"] * float(mpp); df["y_um"] = df["y"] * float(mpp)

    before = len(df)
    df = dedup_by_radius(df, radius_um=dedup_radius_um, prefer_col="area_px")
    print(f"✅ After deduplication: {len(df):,} nuclei (from {before:,}; radius={dedup_radius_um} µm)")

    df["slide_id"] = slide_id
    df["nucleus_id"] = [stable_id(slide_id, x, y) for x, y in zip(df["x_um"], df["y_um"])]
    key_cols = ["slide_id", "nucleus_id", "x", "y", "x_um", "y_um", "area_px"]
    df = df[key_cols + [c for c in df.columns if c not in key_cols]]
    df.to_csv(out_csv, index=False); print(f"📄 Saved features CSV: {out_csv}")

    make_qc_panel(viz_dir, Path(masks_dir).parent / f"qc_panel.jpg")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tiles_dir", required=True)
    ap.add_argument("--tiles_json", required=True)
    ap.add_argument("--masks_dir", required=True)
    ap.add_argument("--out_csv", required=True)
    ap.add_argument("--slide_id", required=True)
    ap.add_argument("--mpp", type=float, required=True)
    ap.add_argument("--diam_um", type=float, default=10.0)
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--gpu", action="store_true", help="(unused; TF handles this)")
    ap.add_argument("--dedup_radius_um", type=float, default=6.0)
    ap.add_argument("--stardist_model", default="2D_versatile_he", help='{"2D_versatile_he","2D_versatile_fluo"} or path to custom model dir')
    ap.add_argument("--prob_thresh", type=float, default=0.5)
    ap.add_argument("--nms_thresh", type=float, default=0.4)
    args = ap.parse_args()

    segment_and_merge(
        tiles_dir=args.tiles_dir, tiles_json=args.tiles_json, masks_dir=args.masks_dir, out_csv=args.out_csv,
        slide_id=args.slide_id, mpp=args.mpp, diam_um=args.diam_um, batch_size=args.batch_size, gpu=args.gpu,
        dedup_radius_um=args.dedup_radius_um, stardist_model=args.stardist_model,
        prob_thresh=args.prob_thresh, nms_thresh=args.nms_thresh
    )

if __name__ == "__main__":
    main()
