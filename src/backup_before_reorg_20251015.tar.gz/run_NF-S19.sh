#!/bin/bash
bash src/run_one_slide.sh data/raw/NF-S19.svs 2>&1 | tee logs/NF-S19.log
