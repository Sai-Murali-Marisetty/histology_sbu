#!/usr/bin/env python3
# 01_tissue_mask.py — Improved Tissue Detection Mask Generator
import argparse
from pathlib import Path
import numpy as np
from PIL import Image
import cv2
import sys

try:
    import openslide
except Exception:
    sys.stderr.write(
        "ERROR: openslide-python is required. Install it via pip and ensure OpenSlide libs are installed.\n"
    )
    raise


def generate_tissue_mask(slide_path: str, out_path: str, level: int = 2):
    slide = openslide.OpenSlide(slide_path)
    if level >= slide.level_count:
        raise ValueError(f"Slide has only {slide.level_count} levels; got level={level}.")

    w, h = slide.level_dimensions[level]
    img = slide.read_region((0, 0), level, (w, h)).convert("RGB")
    img_np = np.array(img)

    # --- HSV threshold (looser to include more tissue) ---
    hsv = cv2.cvtColor(img_np, cv2.COLOR_RGB2HSV)
    H, S, V = cv2.split(hsv)
    mask = ((S > 10) & (V > 20)).astype(np.uint8) * 255

    # --- Morphological cleanup ---
    # Close gaps inside tissue
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((25, 25), np.uint8), iterations=2)
    # Remove small specks
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8), iterations=1)

    # --- Keep only largest connected component (main tissue) ---
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if num_labels > 1:
        largest = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])  # skip background
        mask = np.where(labels == largest, 255, 0).astype(np.uint8)

    # --- Save result ---
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(mask).save(out_path)
    print(f"✅ Saved tissue mask at level {level}: {out_path}  (size={w}×{h})")


def main():
    ap = argparse.ArgumentParser(description="Generate a binary tissue mask from a WSI using HSV thresholds and morphology.")
    ap.add_argument("--raw", required=True, help="Path to .svs slide")
    ap.add_argument("--out", required=True, help="Output path for mask (.png/.tif)")
    ap.add_argument("--level", type=int, default=2, help="OpenSlide level to use (default 2)")
    ap.add_argument("--overwrite", action="store_true", help="Overwrite out file if it exists")
    args = ap.parse_args()

    if Path(args.out).exists() and not args.overwrite:
        print(f"⚠️ Output exists, skipping (use --overwrite to force): {args.out}")
        return
    generate_tissue_mask(args.raw, args.out, level=args.level)


if __name__ == "__main__":
    main()
