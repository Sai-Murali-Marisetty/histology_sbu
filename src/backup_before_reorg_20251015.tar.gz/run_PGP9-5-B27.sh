#!/bin/bash
bash src/run_one_slide.sh data/raw/PGP9-5-B27.svs 2>&1 | tee logs/PGP9-5-B27.log
